import { Unzip, UnzipInflate } from 'fflate';
import { createHash } from 'node:crypto';

export const LIMITS = Object.freeze({ archive: 150 * 1024 * 1024, cloudArchive: 50_000_000, file: 64 * 1024 * 1024, image: 16 * 1024 * 1024, resource: 16 * 1024 * 1024, text: 2 * 1024 * 1024, files: 260, screens: 200 });
export class HandoffError extends Error {}
export function checkCancelled(signal) { if (signal?.aborted) throw new HandoffError('MCP request was cancelled.'); }
const fail = message => { throw new HandoffError(message); };
export function safePath(value) {
  if (typeof value !== 'string' || !value || value.length > 512 || /[\\\x00-\x1f\x7f:]/u.test(value) || value.startsWith('/') || value.split('/').some(part => !part || part === '.' || part === '..')) fail('Unsafe package file path.');
  return value;
}

// Validate central-directory sizes before inflating, then check actual output and
// CRC. Never extract to disk: an archive cannot overwrite files or follow links.
function directory(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50 && i + 22 + view.getUint16(i + 20, true) === bytes.length) { end = i; break; }
  }
  if (end < 0 || view.getUint16(end + 4, true) || view.getUint16(end + 6, true)) fail('Unsupported or incomplete ZIP.');
  const count = view.getUint16(end + 10, true), size = view.getUint32(end + 12, true), offset = view.getUint32(end + 16, true);
  if (!count || count > LIMITS.files || count !== view.getUint16(end + 8, true) || offset + size !== end) fail('Unsupported ZIP directory or too many files.');
  const entries = new Map();
  let cursor = offset, total = 0;
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > end || view.getUint32(cursor, true) !== 0x02014b50) fail('Invalid ZIP directory.');
    const flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true);
    const crc = view.getUint32(cursor + 16, true), compressed = view.getUint32(cursor + 20, true), original = view.getUint32(cursor + 24, true);
    const nameLength = view.getUint16(cursor + 28, true), extraLength = view.getUint16(cursor + 30, true), commentLength = view.getUint16(cursor + 32, true);
    const mode = view.getUint32(cursor + 38, true) >>> 16, localOffset = view.getUint32(cursor + 42, true);
    const next = cursor + 46 + nameLength + extraLength + commentLength;
    if (next > end || localOffset + 30 > offset || compressed === 0xffffffff || original === 0xffffffff || flags & 1 || ![0, 8].includes(method) || (mode & 0xf000) === 0xa000) fail('Unsupported ZIP entry.');
    const name = new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
    safePath(name.endsWith('/') ? name.slice(0, -1) : name);
    if (entries.has(name)) fail('Duplicate package file.');
    if (original > LIMITS.file || (total += original) > LIMITS.archive) fail('Package exceeds the uncompressed size limit.');
    if (view.getUint32(localOffset, true) !== 0x04034b50) fail('Invalid ZIP entry header.');
    const localNameLength = view.getUint16(localOffset + 26, true), localExtra = view.getUint16(localOffset + 28, true);
    const dataOffset = localOffset + 30 + localNameLength + localExtra;
    if (dataOffset + compressed > offset || view.getUint16(localOffset + 8, true) !== method || view.getUint16(localOffset + 6, true) !== flags || new TextDecoder('utf-8', { fatal: true }).decode(bytes.subarray(localOffset + 30, localOffset + 30 + localNameLength)) !== name) fail('ZIP headers do not match.');
    entries.set(name, { original, crc, method });
    cursor = next;
  }
  if (cursor !== end) fail('Invalid ZIP directory length.');
  return entries;
}
const crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
  for (let k = 0; k < 8; k++) n = (n & 1) ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  return n >>> 0;
});
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
export function decodeArchive(bytes) {
  if (bytes.length > LIMITS.archive || bytes.length < 22) fail('ZIP exceeds the size limit or is incomplete.');
  const expected = directory(bytes), files = new Map(), seen = new Set();
  let total = 0;
  const unzip = new Unzip(file => {
    const entry = expected.get(file.name);
    if (!entry || seen.has(file.name) || file.compression !== entry.method) fail('Unexpected ZIP entry.');
    seen.add(file.name);
    const chunks = [];
    let length = 0;
    file.ondata = (error, data, final) => {
      if (error) fail('Cannot decode this ZIP.');
      length += data.length; total += data.length;
      if (length > entry.original || length > LIMITS.file || total > LIMITS.archive) { file.terminate(); fail('Package exceeds the size limit.'); }
      chunks.push(data);
      if (final) {
        const output = new Uint8Array(length);
        let cursor = 0;
        for (const chunk of chunks) { output.set(chunk, cursor); cursor += chunk.length; }
        if (length !== entry.original || crc32(output) !== entry.crc) fail('Corrupted ZIP file.');
        files.set(file.name, output);
      }
    };
    file.start();
  });
  unzip.register(UnzipInflate);
  for (let offset = 0; offset < bytes.length; offset += 1024) unzip.push(bytes.subarray(offset, offset + 1024), offset + 1024 >= bytes.length);
  if (files.size !== expected.size) fail('Incomplete ZIP.');
  const manifests = [...files.keys()].filter(name => name === 'flow.json' || name.endsWith('/flow.json'));
  if (manifests.length !== 1) fail('Choose a Flow Capture export containing one flow.json.');
  const prefix = manifests[0].slice(0, -'flow.json'.length);
  const relative = new Map();
  for (const [name, data] of files) {
    if (name.endsWith('/')) continue;
    if (!name.startsWith(prefix)) fail('File outside the project folder.');
    relative.set(safePath(name.slice(prefix.length)), data);
  }
  const manifest = JSON.parse(readText(relative, 'flow.json'));
  validateManifest(manifest, relative);
  const id = createHash('sha256').update(bytes).digest('hex');
  return { id, manifest, files: relative };
}
export function readText(files, name) {
  const bytes = files.get(safePath(name));
  if (!bytes) fail('File is not present in this export.');
  if (bytes.length > LIMITS.text) fail('Text file exceeds the response limit.');
  return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
}
export function imageMime(bytes) {
  if (bytes?.[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (bytes?.length >= 8 && [137,80,78,71,13,10,26,10].every((value, index) => bytes[index] === value)) return 'image/png';
  fail('Screen file is not a supported image.');
}
function validateManifest(manifest, files) {
  if (!Number.isInteger(manifest?.schemaVersion) || manifest.schemaVersion < 1 || manifest.schemaVersion > 6) fail('Unsupported export version.');
  if (typeof manifest?.project?.name !== 'string' || !manifest.project.name.trim() || manifest.project.name.length > 1000) fail('Missing project name.');
  if (!Array.isArray(manifest.screens) || !manifest.screens.length || manifest.screens.length > LIMITS.screens) fail('Invalid screen count.');
  const orders = new Set();
  for (const screen of manifest.screens) {
    if (!Number.isInteger(screen.order) || screen.order < 1 || orders.has(screen.order) || typeof screen.title !== 'string') fail('Invalid screen order or title.');
    orders.add(screen.order);
    const bytes = files.get(safePath(screen.file));
    imageMime(bytes);
    if (bytes.length > LIMITS.image) fail('Screen image exceeds the response size limit.');
  }
  if (manifest.voiceComments !== undefined && !Array.isArray(manifest.voiceComments)) fail('Invalid comments.');
  for (const comment of manifest.voiceComments ?? []) {
    if (typeof comment?.text !== 'string') fail('Invalid comment text.');
    const linked = comment.linkedScreenOrders ?? (comment.linkedScreenOrder == null ? [] : [comment.linkedScreenOrder]);
    if (!Array.isArray(linked) || linked.some(order => !orders.has(order))) fail('Comment references a missing screen.');
    if (comment.audioFile && !files.has(safePath(comment.audioFile))) fail('Comment audio is missing.');
  }
  if (manifest.narrationAudioFile && !files.has(safePath(manifest.narrationAudioFile))) fail('Narration audio is missing.');
}
