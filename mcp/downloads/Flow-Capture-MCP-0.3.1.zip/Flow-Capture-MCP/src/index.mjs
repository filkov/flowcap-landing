#!/usr/bin/env node
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { LocalInbox } from './inbox.mjs';
import { createServer } from './server.mjs';
import { CloudInbox } from './cloud.mjs';

const args = process.argv.slice(2);
if (!((args.length === 2 && args[0] === '--inbox') || (args.length === 4 && args[0] === '--cloud' && args[2] === '--credentials')) || !args[1]) {
  console.error('Usage: node src/index.mjs --inbox /absolute/path/to/exports OR --cloud https://project.supabase.co --credentials /absolute/private/path/cloud.json');
  process.exitCode = 1;
} else {
  const inbox = args[0] === '--cloud' ? new CloudInbox(args[1],args[3]) : new LocalInbox(args[1]);
  const server = createServer(inbox);
  await server.connect(new StdioServerTransport());
  // stdout belongs exclusively to the MCP transport. Diagnostics use stderr.
  for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, async () => { await server.close(); process.exit(0); });
}
