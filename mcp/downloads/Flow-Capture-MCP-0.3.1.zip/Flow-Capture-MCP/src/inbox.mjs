import { open, readdir, realpath } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { Worker } from 'node:worker_threads';
import { HandoffError, LIMITS, checkCancelled } from './archive.mjs';

export function decodeBounded(bytes, { signal } = {}) {
  return new Promise((resolve, reject) => {
    checkCancelled(signal);
    // A subarray may share its backing buffer with unrelated data. Transfer only
    // the requested ZIP view and do not detach the caller's other bytes.
    const buffer = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength
      ? bytes.buffer : bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
    const worker = new Worker(new URL('./archive-worker.mjs', import.meta.url), { execArgv: [],workerData: buffer, transferList: [buffer], resourceLimits: { maxOldGenerationSizeMb: 192 } });
    let settled = false;
    const abort = () => finish(new HandoffError('MCP request was cancelled.'));
    const timeout = setTimeout(() => finish(new HandoffError('Archive took too long to decode. Export it again with fewer screens.')), 10000);
    function finish(error, item) {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      signal?.removeEventListener('abort', abort);
      void worker.terminate().catch(() => {});
      if (error) reject(error); else resolve(item);
    }
    worker.once('message', result => finish(result.error ? new HandoffError(result.error) : null, result.item));
    worker.once('error', error => finish(new HandoffError(error.code === 'ERR_WORKER_OUT_OF_MEMORY' ? 'Cannot decode this export within the memory limit.' : 'Archive decoder could not start. Restart the MCP server.')));
    worker.once('exit', () => finish(new HandoffError('Archive decoder stopped.')));
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
  });
}

export class LocalInbox {
  constructor(root) { this.root = path.resolve(root); this.index = new Map(); }
  async archives() {
    const root = await realpath(this.root);
    const entries = await readdir(root, { withFileTypes: true });
    const names = entries.filter(entry => entry.isFile() && /\.zip$/i.test(entry.name)).map(entry => entry.name).sort();
    if (names.length > 100) throw new HandoffError('Inbox contains more than 100 ZIPs. Move older exports to another folder.');
    return names.map(name => path.join(root, name));
  }
  async load(file, { signal } = {}) {
    checkCancelled(signal);
    // O_NOFOLLOW closes the symlink race between directory scanning and open.
    const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const before = await handle.stat();
      if (!before.isFile() || before.size > LIMITS.archive) throw new HandoffError('Archive exceeds the size limit.');
      const bytes = Buffer.allocUnsafeSlow(before.size);
      let offset = 0;
      while (offset < bytes.length) {
        checkCancelled(signal);
        const result = await handle.read(bytes, offset, Math.min(1024 * 1024, bytes.length - offset), offset);
        if (!result.bytesRead) throw new HandoffError('Archive is still being copied. Retry after the copy finishes.');
        offset += result.bytesRead;
      }
      const after = await handle.stat();
      if (before.size !== after.size || before.mtimeMs !== after.mtimeMs) throw new HandoffError('Archive is still being copied. Retry after the copy finishes.');
      return await decodeBounded(bytes, { signal });
    } finally { await handle.close(); }
  }
  async list({ offset = 0, limit = 10, signal } = {}) {
    checkCancelled(signal);
    if (!Number.isInteger(offset) || offset < 0 || offset > 100 || !Number.isInteger(limit) || limit < 1 || limit > 10) throw new HandoffError('Invalid inbox page.');
    const projects = [], rejected = [];
    const seen = new Set();
    const archives = await this.archives();
    const current = new Set(archives);
    for (const [id, file] of this.index) if (!current.has(file)) this.index.delete(id);
    for (const file of archives.slice(offset, offset + limit)) {
      checkCancelled(signal);
      try {
        const item = await this.load(file, { signal });
        if (seen.has(item.id)) continue;
        seen.add(item.id);
        for (const [id, indexed] of this.index) if (indexed === file && id !== item.id) this.index.delete(id);
        this.index.set(item.id, file);
        projects.push({ id: item.id, name: item.manifest.project.name, exportedAt: item.manifest.exportedAt ?? null, screenCount: item.manifest.screens.length, commentCount: item.manifest.voiceComments?.length ?? 0 });
      } catch (error) { checkCancelled(signal); rejected.push({ archive: path.basename(file), reason: publicError(error) }); }
    }
    return { projects, rejected, next_offset: offset + limit < archives.length ? offset + limit : null };
  }
  async get(id, { signal } = {}) {
    checkCancelled(signal);
    if (!/^[a-f0-9]{64}$/.test(id)) throw new HandoffError('Invalid project ID.');
    const file = this.index.get(id);
    if (file && (await this.archives()).includes(file)) {
      const item = await this.load(file, { signal });
      if (item.id === id) return item;
      this.index.delete(id);
    }
    throw new HandoffError('Export no longer exists in the inbox. List projects again to select the current export.');
  }
}
export function publicError(error) {
  if (error instanceof HandoffError) return error.message;
  if (error?.code === 'ENOENT') return 'Inbox does not exist. Create the configured folder and save an exported ZIP there.';
  return 'Cannot read this export. Check that copying has finished and export it again if necessary.';
}
