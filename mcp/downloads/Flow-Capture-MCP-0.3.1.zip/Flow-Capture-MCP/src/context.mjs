import sharp from 'sharp';
import { HandoffError, imageMime } from './archive.mjs';

export const TEXT_PAGE = 6000;
export function textPage(value, offset = 0, limit = TEXT_PAGE) {
  if (offset > value.length) throw new HandoffError('Text offset is outside this file.');
  // Offsets are UTF-16 positions; never split a surrogate pair between pages.
  if (offset > 0 && /[\uDC00-\uDFFF]/u.test(value[offset] ?? '') && /[\uD800-\uDBFF]/u.test(value[offset - 1])) throw new HandoffError('Offset splits a Unicode character. Use next_offset from the previous page.');
  let end = Math.min(value.length, offset + limit);
  if (end < value.length && /[\uD800-\uDBFF]/u.test(value[end - 1])) {
    // A limit of one cannot hold a surrogate pair; return that whole character
    // rather than an empty page whose next_offset repeats forever.
    if (end - 1 === offset) end++; else end--;
  }
  return { text: value.slice(offset, end), offset, next_offset: end < value.length ? end : null, total_characters: value.length };
}
export function recordPreview(value) {
  if (JSON.stringify(value).length <= 700) return value;
  const result = { truncated: true, full_text: 'Use get_text with file flow.json for complete data; this preview is not the complete comment.' };
  for (const key of ['order', 'title', 'file', 'name', 'kind', 'status', 'text', 'linkedScreenOrder', 'linkedScreenOrders', 'audioFile']) {
    const field = value[key];
    if (typeof field === 'string') result[key] = field.slice(0, 256);
    else if (typeof field === 'number') result[key] = field;
    else if (Array.isArray(field)) result[key] = field.slice(0, 10).filter(entry => typeof entry === 'number' && Number.isFinite(entry));
  }
  return result;
}
export function recordPage(values, offset, limit) {
  return { values: values.slice(offset, offset + limit).map(recordPreview), total: values.length, next_offset: offset + limit < values.length ? offset + limit : null };
}
export async function screenImage(bytes, region) {
  const input = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const options = { limitInputPixels: 40_000_000, failOn: 'warning' };
  let metadata;
  try { metadata = await sharp(input, options).metadata(); }
  catch { throw new HandoffError('This screen image is damaged or too large to decode. Export it again.'); }
  const swapped = [5,6,7,8].includes(metadata.orientation);
  const width = swapped ? metadata.height : metadata.width, height = swapped ? metadata.width : metadata.height;
  if (!width || !height) throw new HandoffError('Screen dimensions are unavailable.');
  let pipeline = sharp(input, options).rotate();
  if (region) {
    if (region.x + region.width > 1 || region.y + region.height > 1) throw new HandoffError('Region must fit inside the screen.');
    // Materialize orientation before cropping so coordinates match the displayed image.
    const oriented = await pipeline.png().toBuffer();
    const left = Math.floor(region.x * width), top = Math.floor(region.y * height);
    pipeline = sharp(oriented, options).extract({ left, top, width: Math.max(1, Math.min(width-left, Math.round(region.width*width))), height: Math.max(1, Math.min(height-top, Math.round(region.height*height))) });
  } else if (bytes.length <= 2 * 1024 * 1024 && Math.max(width, height) <= 2000 && !metadata.orientation) {
    // Decode even small originals, rather than returning corrupt header-only images.
    await pipeline.stats();
    return { bytes, mimeType: imageMime(bytes), original_width: width, original_height: height, width, height, resized: false };
  }
  try {
    const output = await pipeline.resize({ width: 2000, height: 2000, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 90 }).toBuffer({ resolveWithObject: true });
    if (output.data.length > 2 * 1024 * 1024) throw new HandoffError('This image is too complex for one response. Request a smaller region.');
    return { bytes: output.data, mimeType: 'image/jpeg', width: output.info.width, height: output.info.height, original_width: width, original_height: height, resized: true, region: region ?? null };
  } catch (error) {
    if (error instanceof HandoffError) throw error;
    throw new HandoffError('Cannot decode this screen. Export it again.');
  }
}
