import { parentPort, workerData } from 'node:worker_threads';
import { decodeArchive, HandoffError } from './archive.mjs';
try {
  const item = decodeArchive(new Uint8Array(workerData));
  parentPort.postMessage({ item }, [...item.files.values()].map(bytes => bytes.buffer));
} catch (error) {
  parentPort.postMessage({ error: error instanceof HandoffError ? error.message : 'Cannot decode this export. Export it again if necessary.' });
}
