# Flow Capture MCP

Desktop MCP server for Claude Desktop and Codex, with private cloud delivery or
an offline inbox. It reads the **real AI
ZIP export** from Flow Capture, including ordered screen images, typed/voice
comments, connections, prompt and original audio resources. No model API key is
required. Client inference runs in Claude/Codex; the cloud connector uses a
separate, revocable desktop credential, never the iPhone Auth session.

## Direct delivery from iPhone

1. Restart Claude Desktop/Codex after installing the connector.
2. Ask the assistant to call `connect_account`. In Flow Capture, open
   **Settings → Codex & Claude → Add a Computer**, enter its code and approve the
   computer. Ask the assistant to call `check_connection` afterward.
3. Open a project and choose **Export for Codex or Claude → Send to AI**.
   Confirm the selected ZIP, including available original audio.
4. Use **Copy Request**, then paste into your AI chat to select that exact
   immutable export.

Each client has an independent credential file, so Claude and Codex can be
disconnected separately through the computer's native options menu.
**Settings → Codex & Claude → Shared Access** lets you revoke active cloud
copies without deleting local projects; it is separate from connection setup.
Codes expire in ten
minutes, connections in ninety days, exports in seven days. Incomplete uploads
are cleaned after thirty minutes. Cleanup runs on authenticated bridge traffic;
expired exports are denied even before physical cleanup completes. Signed URLs
last at most sixty seconds; already downloaded files cannot be retracted.
Sending requires server-verified Pro. No voice minutes or AI model credits are
spent by delivery. The client only reads explicitly shared exports.

## Offline delivery

On iPhone, choose **Export for Codex or Claude**, then save/share its ZIP to the
configured folder on your Mac. AirDrop or an already configured shared drive can
transport the ZIP. The server discovers new files on the next `list_projects`
call without restarting. It does not watch or read all of Downloads/Documents.

The server does not insert messages into an existing desktop chat or start an AI
task without the user's request. Sending the package shares it; the assistant
reads it when requested.

## Install on macOS

Requires Node.js 20.9+. From this directory:

```sh
npm ci --ignore-scripts
node install.mjs --cloud https://omhelpzpkowcncvqfnuw.supabase.co
# Optional offline mode:
node install.mjs --inbox "$HOME/Documents/Flow Capture Inbox"
```

The installer copies the runtime out of the Git worktree into
`~/Library/Application Support/Flow Capture/MCP`, installs locked dependencies,
tests the MCP handshake, and configures installed Claude Desktop and Codex.
Other MCP servers and settings remain intact. Configuration backups are saved
alongside their originals with owner-only permissions. It does not restart apps.
Restart Claude and open a new Codex chat/restart Codex to load the new server.

Ask the assistant:

> Use Flow Capture to list the exported projects. Inspect the screens and their
> comments in the project I select, then review the interaction and propose fixes.

No exports are included in the installation. Test fixtures remain in the repo.

## Manual configuration

Claude Desktop `mcpServers` entry (absolute paths required):

```json
{
  "flow-capture": {
    "command": "/absolute/path/to/node",
    "args": ["/absolute/path/to/MCPServer/src/index.mjs", "--inbox", "/absolute/path/to/exports"]
  }
}
```

Codex:

```sh
codex mcp add flow-capture -- /absolute/path/to/node /absolute/path/to/MCPServer/src/index.mjs --inbox /absolute/path/to/exports
```

## Protocol

| Tool | Result |
| --- | --- |
| `connect_account` (cloud) | Short-lived code; requires approval on iPhone. Never returns a session credential. |
| `check_connection` (cloud) | Checks approval and saves the desktop credential locally. |
| `list_projects` | Up to ten ZIPs per page, immutable IDs, screen/comment counts; incomplete exports reported separately. Follow `next_offset` when present. |
| `get_project` | Bounded pages of ordered screens, comments and resource URIs. Follow the separate next offsets. Long records are explicitly marked as previews; complete flow data is available with `get_text`. |
| `get_screen` | One decoded image, at most 2000 px / 2 MiB, with linked comment previews. Optional normalized region magnifies small text; original files are retained. |
| `get_export_prompt` | START_HERE.txt (or legacy README.md), in pages of at most 6000 UTF-16 characters. Follow `next_offset` until null. |
| `get_text` | Complete JSON/TXT/MD files in the same bounded pages, without silently dropping long comments or Unicode characters. |

`flowcapture://exports/{project_id}/files/{file}` resources expose only existing
files inside that ZIP, including audio. Clients vary in their support for binary
resources; image tools and comment transcripts work without audio playback.
Package limits: 200 screens, 260 files; cloud uploads **50,000,000 bytes (50 MB)**, offline ZIPs 150 MiB compressed/uncompressed. Up to 64 MiB per file, 16 MiB per source image/binary resource, 2 MiB per source text file, 100 ZIPs in the offline folder. Tool text is paginated; images are one at a time, at most 2000 px and 2 MiB (before base64). Large text resources redirect to `get_text` instead of returning a giant response. Audio larger than the
resource response limit remains in the ZIP; its comment transcript is still
available through `get_project`. Export schemas
1–6 are supported. IDs are SHA-256 of the ZIP snapshot, so replacing an export
cannot silently change the evidence for an existing ID.

## Safety and verification

The server never writes/deletes projects, executes exported prompts, follows ZIP
or filesystem symlinks, or extracts files to disk. Offline mode has no network
access. Cloud mode verifies the configured HTTPS origin and signed Storage URL,
rechecks authorization on each read and verifies the ZIP hash. One five-minute
in-memory snapshot avoids redownloading the ZIP for each screen; live queue
membership and authorization are checked before every cache read. No offline
cache can bypass revocation. Credential files are owner-only, tied to the
backend origin, and separate for Claude/Codex. The only MCP writes are starting
pairing and storing its credential after approval.
Archive sizes, paths, headers, CRCs, references and image signatures are checked.
Inflation runs in a worker with a memory limit and a ten-second timeout; reads
are serialized to avoid inflating multiple large packages concurrently. Export
text is marked as untrusted data; the assistant must still follow the human's
request. Files may include private screens and comments, so share only exports
you intend the connected AI client to inspect.

```sh
npm test
npm audit
node ../supabase/tests/ai-bridge.mjs
npx deno check ../supabase/functions/ai-bridge/index.ts
```

Tests use the official MCP SDK client over **stdio**, real PNG screens from the
existing runtime fixture, synthetic typed/voice comments, binary resources,
broken/traversal/oversized archives, vanished files and inbox boundaries. No
real user recordings, paid purchases or cloud minute credits are touched.

## Backend and integration testing

`supabase/functions/ai-bridge` uses action-level authentication: mobile Auth JWTs
for account operations and hashed opaque credentials for desktop reads. Private
Storage inserts are allowed only for the exact pending export owned by that
user. Pairing claim is atomic and one-use. Allocation/code-attempt limits and
the per-user thirty-export/1 GiB queue limit are enforced in database functions.
Account deletion removes AI Storage objects before deleting the Auth user.

`node tests/live-cloud.mjs --run` is an explicit opt-in real-backend test. It
creates two disposable users, temporarily grants one Pro, exercises actual ZIP
upload, RLS, stdio MCP images/comments, cross-account denial and revocation,
then deletes test Storage objects and identities. It reads existing CLI access
in memory and never prints credentials. Physical iPhone tests cover native
pairing approval/cancel, sign-in navigation, export confirmation and sending.

This is a local stdio MCP connector backed by cloud delivery. A remote
Streamable HTTP/OAuth MCP endpoint is a future transport; it is not required for
the installed Claude Desktop/Codex connection.

## Reliability follow-up (0.2.1)

Connection updates use a cross-process lease lock, preventing overlapping MCP
launches from replacing each other’s pairing code. Expired pending state recovers
locally; damaged credentials fail with repair instructions. Reads retain one
credential throughout and recheck access after download/decode before returning
data. Upload completion/cancellation and retention use conditional state
transitions before Storage deletion. Regression evidence is in
`Docs/MCP_AUDIT_2026-10-14.md`; backend state tests run with
`npx deno test supabase/functions/ai-bridge/upload-state.test.ts`.

## Size, timing and expected replies (0.3.0)

Recording duration is not an upload limit: AI exports omit the source video.
Size depends on retained screenshots, comments and available original audio.
A five-minute recording with a few screens may be smaller than a one-minute
recording with many distinct screens. Raw audio is not universally supported
by Claude/Codex MCP clients: obtain a transcript in Flow Capture first for a
reliable text review. Sending itself does not transcribe or spend voice minutes.

The app preflights its native ZIP before upload, displays screen count/size,
reports checking/uploading/finishing stages and permits cancellation. Success
means **Ready in AI Inbox**, followed by **Copy MCP Prompt**, not “AI analyzed
your project.” The reply appears in the chosen assistant chat, using that
client's normal tool/activity UI. No result is pushed back to the iPhone.
The assistant is told to retrieve the export prompt and paginated comments,
inspect relevant images, and state uninspected context or unprocessed audio.
Model context, plan quotas, tool deadlines and client rendering still apply;
the server cannot promise every arbitrary prompt fits every model.

The installed Codex entry uses a 180-second tool timeout for cold downloads
instead of the documented 60-second default, with explicit output budgets for
context/image/text tools to prevent normal pages using the client's smaller default
truncation budget. Claude deadlines are controlled
by Claude. One authorized in-memory snapshot avoids repeat downloads for five
minutes. Data transfers and model analysis are separate timings; a successful
network benchmark is not a guarantee of model answer latency.

Reproduce real transfer benchmarks with synthetic data only:
`node tests/live-cloud.mjs --run --benchmark`. This also verifies the exact
50 MB boundary and rejection of 50,000,001 bytes, and deletes its temporary
accounts and objects. Results and official limit sources are recorded in
`Docs/MCP_SIZE_AND_LATENCY_2026-10-14.md`.

## Audit follow-up (0.3.1)

MCP read cancellation now skips queued reads and reaches network downloads and
archive workers; subsequent calls remain usable. Tiny Unicode pages always
advance. ZIP subarrays decode without including/detaching unrelated parent data.
Nested metadata cannot expand a preview beyond its intended bounds, and malformed
service JSON gives a service retry error instead of blaming the export.
See `Docs/MCP_AUDIT_FOLLOWUP_2026-10-14.md` for reproduced failures and verification.
