#!/usr/bin/env node
import { cp, mkdir, readFile, writeFile, rename, copyFile, chmod } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { homedir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const cloud = args[0] === '--cloud';
if (args.length !== 2 || (!cloud && (args[0] !== '--inbox' || !path.isAbsolute(args[1])))) {
  console.error('Usage: node install.mjs --inbox /absolute/path/to/shared-exports OR --cloud https://project.supabase.co');
  process.exit(1);
}
if (process.platform !== 'darwin') throw new Error('This installer currently supports macOS. See README for manual configuration on other platforms.');
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 20 || (major === 20 && minor < 9)) throw new Error('Node.js 20.9 or newer is required.');
const source = path.dirname(fileURLToPath(import.meta.url));
const runtime = path.join(homedir(), 'Library/Application Support/Flow Capture/MCP');
const inbox = args[1];
const claudeConfig = path.join(homedir(), 'Library/Application Support/Claude/claude_desktop_config.json');
const codexConfig = path.join(homedir(), '.codex/config.toml');
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
if (cloud) {
  const url = new URL(args[1]);
  if (url.protocol !== 'https:' || url.pathname !== '/' || url.username || url.password || url.search || url.hash) throw new Error('Cloud backend must be an HTTPS origin.');
} else await mkdir(inbox, { recursive: true, mode: 0o700 });
await mkdir(runtime, { recursive: true, mode: 0o700 });
await cp(path.join(source, 'src'), path.join(runtime, 'src'), { recursive: true });
for (const file of ['package.json', 'package-lock.json']) await copyFile(path.join(source, file), path.join(runtime, file));
const installed = spawnSync('npm', ['ci', '--ignore-scripts', '--omit=dev'], { cwd: runtime, stdio: 'inherit' });
if (installed.status !== 0) throw new Error('Runtime installation failed. Client configuration was not changed.');

// Confirm installed runtime and SDK before touching either client's settings.
const { Client } = await import('@modelcontextprotocol/sdk/client/index.js');
const { StdioClientTransport } = await import('@modelcontextprotocol/sdk/client/stdio.js');
const client = new Client({ name: 'flow-capture-installer', version: '0.1.0' });
try {
  const launch = cloud ? ['--cloud',args[1],'--credentials',path.join(runtime,'codex-cloud.json')] : ['--inbox',inbox];
  await client.connect(new StdioClientTransport({ command: process.execPath, args: [path.join(runtime, 'src/index.mjs'), ...launch], stderr: 'pipe' }));
  if ((await client.listTools()).tools.length !== (cloud ? 7 : 5)) throw new Error('Installed runtime did not expose the expected tools.');
} finally { await client.close(); }

async function backup(file) {
  if (existsSync(file)) {
    const target = `${file}.flow-capture-backup-${stamp}`;
    await copyFile(file, target);
    await chmod(target, 0o600);
  }
}
const server = { command: process.execPath, args: [path.join(runtime, 'src/index.mjs'), ...(cloud ? ['--cloud',args[1],'--credentials',path.join(runtime,'codex-cloud.json')] : ['--inbox',inbox])] };
if (existsSync('/Applications/Claude.app') || existsSync(claudeConfig)) {
  const config = existsSync(claudeConfig) ? JSON.parse(await readFile(claudeConfig, 'utf8')) : {};
  if (!config || typeof config !== 'object' || Array.isArray(config) || (config.mcpServers && (typeof config.mcpServers !== 'object' || Array.isArray(config.mcpServers)))) throw new Error('Claude configuration format is unsupported; it was not modified.');
  await backup(claudeConfig);
  const claudeServer = cloud ? { ...server,args:[path.join(runtime,'src/index.mjs'),'--cloud',args[1],'--credentials',path.join(runtime,'claude-cloud.json')] } : server;
  config.mcpServers = { ...config.mcpServers, 'flow-capture': claudeServer };
  await mkdir(path.dirname(claudeConfig), { recursive: true });
  const temporary = `${claudeConfig}.flow-capture-tmp`;
  await writeFile(temporary, JSON.stringify(config, null, 2) + '\n', { mode: 0o600 });
  await rename(temporary, claudeConfig);
  console.log('Configured Flow Capture for Claude Desktop. Restart Claude when convenient.');
}
const available = spawnSync('codex', ['--version'], { stdio: 'ignore' });
if (available.status === 0) {
  await backup(codexConfig);
  const result = spawnSync('codex', ['mcp', 'add', 'flow-capture', '--', server.command, ...server.args], { stdio: 'inherit' });
  if (result.status !== 0) throw new Error('Codex configuration failed. Its configuration backup is retained.');
  // A cold 50 MB download can exceed Codex's default 60-second tool deadline.
  const configuration = await readFile(codexConfig, 'utf8');
  const updated = configuration.replace(/(\[mcp_servers\.flow-capture\]\n)([\s\S]*?)(?=\n\[|$)/, (_, header, body) => header + body.replace(/^(?:tool_timeout_sec|tools\.(?:get_project|get_screen|get_text|get_export_prompt)\.output_token_limit)\s*=.*\n?/gm, '').trimEnd() + '\ntool_timeout_sec = 180\ntools.get_project.output_token_limit = 16384\ntools.get_screen.output_token_limit = 8192\ntools.get_text.output_token_limit = 8192\ntools.get_export_prompt.output_token_limit = 8192\n');
  await writeFile(codexConfig, updated, { mode: 0o600 });
  console.log('Configured Flow Capture for Codex. Open a new chat or restart Codex to load it.');
}
console.log(cloud ? `Private AI inbox backend: ${args[1]}. Ask the assistant to call connect_account.` : `Shared export inbox: ${inbox}`);
