import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { open, mkdir, rename, chmod } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { HandoffError, LIMITS, checkCancelled } from './archive.mjs';
import { decodeBounded } from './inbox.mjs';
import lockfile from 'proper-lockfile';

async function boundedBody(response, limit) {
  const reader = response.body?.getReader();
  if (!reader) throw new HandoffError('Empty AI service response.');
  const chunks = []; let length = 0;
  while (true) {
    const { done, value } = await reader.read(); if (done) break;
    length += value.length;
    if (length > limit) { await reader.cancel(); throw new HandoffError('AI service response exceeds the size limit.'); }
    chunks.push(value);
  }
  const output = Buffer.allocUnsafeSlow(length); let offset = 0;
  for (const chunk of chunks) { output.set(chunk,offset); offset += chunk.length; }
  return output;
}
export class CloudInbox {
  constructor(base, credentialFile, fetcher = fetch) {
    this.base = new URL(base);
    if (this.base.protocol !== 'https:' || this.base.username || this.base.password || this.base.pathname !== '/' || this.base.search || this.base.hash) throw new HandoffError('Cloud backend must be an HTTPS origin.');
    this.credentialFile = path.resolve(credentialFile); this.fetcher = fetcher;
    this.endpoint = new URL('/functions/v1/ai-bridge',this.base);
    this.remote = true;
  }
  async state() {
    let file;
    try {
      file = await open(this.credentialFile,constants.O_RDONLY | constants.O_NOFOLLOW);
      const stat = await file.stat();
      if (!stat.isFile() || stat.size > 8192 || (stat.mode & 0o077)) throw new HandoffError('MCP credentials must be an owner-only file.');
      let state;
      try { state = JSON.parse(await file.readFile('utf8')); }
      catch { throw new HandoffError('MCP credentials are damaged. Restore the credential file or remove it and run connect_account again.'); }
      if (!state || typeof state !== 'object' || Array.isArray(state) || (state.token !== undefined && !/^[a-f0-9]{64}$/.test(state.token))) throw new HandoffError('MCP credentials are damaged. Restore the credential file or remove it and run connect_account again.');
      if (state.pending !== undefined && (!state.pending || typeof state.pending !== 'object' || Array.isArray(state.pending) || !/^[A-HJ-NP-Z2-9]{8}$/.test(state.pending.code) || !/^[a-f0-9]{64}$/.test(state.pending.token) || typeof state.pending.pairing_id !== 'string' || typeof state.pending.pairing_secret !== 'string' || !Number.isFinite(Date.parse(state.pending.expires_at)))) throw new HandoffError('MCP credentials are damaged. Restore the credential file or remove it and run connect_account again.');
      if (state.backend_origin && state.backend_origin !== this.base.origin) throw new HandoffError('These MCP credentials belong to a different backend. Use a separate credential file.');
      return state;
    } catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
    finally { await file?.close(); }
  }
  async save(state) {
    await mkdir(path.dirname(this.credentialFile),{ recursive:true,mode:0o700 });
    const temporary = `${this.credentialFile}.${randomUUID()}.tmp`;
    const file = await open(temporary,'wx',0o600);
    try { await file.writeFile(JSON.stringify({ ...state,backend_origin:this.base.origin })); await file.sync(); } finally { await file.close(); }
    await rename(temporary,this.credentialFile); await chmod(this.credentialFile,0o600);
  }
  async request(action, body = {}, token, signal) {
    checkCancelled(signal);
    let response;
    try { response = await this.fetcher(this.endpoint,{ method:'POST',redirect:'error',headers:{ 'Content-Type':'application/json',...(token ? { Authorization:`Bearer ${token}` } : {}) },body:JSON.stringify({ action,...body }),signal:AbortSignal.any([AbortSignal.timeout(20000), ...(signal ? [signal] : [])]) }); }
    catch { checkCancelled(signal); throw new HandoffError('Cannot reach Flow Capture. Check your internet connection and try again.'); }
    let result;
    try { result = JSON.parse((await boundedBody(response,256*1024)).toString('utf8')); }
    catch { checkCancelled(signal); throw new HandoffError('Invalid AI service response. Try again.'); }
    checkCancelled(signal);
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new HandoffError('Invalid AI service response. Try again.');
    if (!response.ok) {
      if (response.status === 401 && token) throw new HandoffError('MCP access expired or was disconnected. Use connect_account again.');
      throw new HandoffError(typeof result.error === 'string' ? result.error.slice(0,250) : 'The AI service is unavailable. Try again.');
    }
    return result;
  }
  async withCredentialLock(operation) {
    await mkdir(path.dirname(this.credentialFile),{ recursive:true,mode:0o700 });
    let compromised = false, release;
    try {
      release = await lockfile.lock(this.credentialFile,{ realpath:false,stale:30000,update:10000,retries:{ retries:40,minTimeout:50,maxTimeout:500 },onCompromised:()=>{compromised=true;} });
    } catch { throw new HandoffError('Another MCP process is updating this connection. Try again shortly.'); }
    try {
      const result = await operation();
      if (compromised) throw new HandoffError('The connection file changed during pairing. Check the connection again.');
      return result;
    } finally { await release().catch(()=>{}); }
  }
  async connect(label = 'This computer') {
    return this.withCredentialLock(()=>this.connectLocked(label));
  }
  async connectLocked(label) {
    const state = await this.state();
    if (state.token) {
      try { return await this.request('connection_status',{},state.token); }
      catch (error) { if (!error.message.includes('expired or was disconnected')) throw error; }
    }
    if (state.pending && new Date(state.pending.expires_at).getTime() > Date.now()) return { connected:false, code:state.pending.code, expires_at:state.pending.expires_at, instructions:'On iPhone: Settings → Integrations → Codex & Claude → Add a Computer. Enter this code and confirm the computer. Then call check_connection.' };
    const token = randomBytes(32).toString('hex'), installation = state.installation_id ?? randomUUID();
    const pending = await this.request('start_pairing',{ installation_id:installation,label,token_hash:createHash('sha256').update(token).digest('hex') });
    await this.save({ installation_id:installation,pending:{ ...pending,token } });
    return { connected:false,code:pending.code,expires_at:pending.expires_at,instructions:'On iPhone: Settings → Integrations → Codex & Claude → Add a Computer. Enter this code and confirm the computer. Then call check_connection.' };
  }
  async checkConnection() {
    return this.withCredentialLock(()=>this.checkConnectionLocked());
  }
  async checkConnectionLocked() {
    const state = await this.state();
    if (state.token) return this.request('connection_status',{},state.token);
    if (!state.pending) return { connected:false,instructions:'Call connect_account to get a pairing code.' };
    if (!Number.isFinite(Date.parse(state.pending.expires_at)) || Date.parse(state.pending.expires_at) <= Date.now()) {
      await this.save({ installation_id:state.installation_id });
      return { connected:false,status:'expired',instructions:'The code expired. Call connect_account for a new code, then approve it in Flow Capture on iPhone.' };
    }
    const result = await this.request('pairing_status',{ installation_id:state.installation_id,pairing_id:state.pending.pairing_id,pairing_secret:state.pending.pairing_secret });
    if (result.status === 'connected') {
      await this.save({ installation_id:state.installation_id,token:state.pending.token,connection_id:result.connection_id,expires_at:result.expires_at });
      return { connected:true,label:result.label,expires_at:result.expires_at };
    }
    if (result.status === 'expired') await this.save({ installation_id:state.installation_id });
    return { connected:false,status:result.status,instructions:result.status === 'expired' ? 'The code expired. Call connect_account for a new code, then approve it in Flow Capture on iPhone.' : 'Waiting for approval. On iPhone, open Settings → Integrations → Codex & Claude → Add a Computer, enter the code and confirm. Ask the user to finish before checking again.' };
  }
  async token() {
    const state = await this.state();
    if (!state.token) throw new HandoffError('Connect this computer first: call connect_account, approve the code on iPhone, then check_connection.');
    return state.token;
  }
  async items(token, signal) {
    const result = await this.request('list_exports',{},token ?? await this.token(),signal);
    if (!Array.isArray(result.items) || result.items.length > 30) throw new HandoffError('Invalid AI inbox response.');
    return result.items;
  }
  async list({ offset = 0,limit = 10,signal } = {}) {
    const items = await this.items(undefined,signal);
    const selected = items.slice(offset,offset+limit);
    return { projects:selected.map(item=>({ id:item.archive_hash,name:item.project_name,exportedAt:item.created_at,expiresAt:item.expires_at,bytes:item.byte_count })),rejected:[],next_offset:offset+limit < items.length ? offset+limit : null };
  }
  async get(id, { signal } = {}) {
    checkCancelled(signal);
    // Recheck authorization for every request, including previously read exports.
    // No offline cache may bypass account revocation or export deletion/expiry.
    const token = await this.token();
    checkCancelled(signal);
    const credential = createHash('sha256').update(token).digest('hex');
    const item = (await this.items(token,signal)).find(item=>item.archive_hash===id);
    if (!item) throw new HandoffError('Export is missing or expired. Send it again from Flow Capture.');
    // One in-memory snapshot avoids downloading the whole ZIP for every screen.
    // Authorization and live queue membership above still run on every read.
    if (this.snapshot?.item.id === id && this.snapshot.credential === credential && this.snapshot.expires > Date.now()) return this.snapshot.item;
    this.snapshot = undefined;
    const signed = await this.request('get_export',{ item_id:item.id },token,signal);
    const resource = new URL(signed.signed_url);
    if (resource.origin !== this.base.origin || !resource.pathname.startsWith('/storage/v1/object/sign/ai-inbox/') || resource.username || resource.password) throw new HandoffError('Invalid export download destination.');
    if (!Number.isSafeInteger(signed.byte_count) || signed.byte_count > LIMITS.cloudArchive || signed.byte_count < 22 || signed.archive_hash !== id) throw new HandoffError('Invalid export metadata.');
    let response;
    try { response = await this.fetcher(resource,{ redirect:'error',signal:AbortSignal.any([AbortSignal.timeout(120000), ...(signal ? [signal] : [])]) }); }
    catch { checkCancelled(signal); throw new HandoffError('Export download failed. Check your connection and try again.'); }
    if (!response.ok) throw new HandoffError('Export download expired or failed. Try again.');
    let bytes;
    try { bytes = await boundedBody(response,signed.byte_count); }
    catch (error) { checkCancelled(signal); if (error instanceof HandoffError) throw error; throw new HandoffError('Export download failed. Check your connection and try again.'); }
    if (bytes.length !== signed.byte_count || createHash('sha256').update(bytes).digest('hex') !== id) throw new HandoffError('Export is incomplete or has changed. Send it again from Flow Capture.');
    const decoded = await decodeBounded(bytes, { signal });
    if (!(await this.items(token,signal)).some(current=>current.archive_hash===id)) throw new HandoffError('Export was removed or expired during download. Send it again from Flow Capture.');
    this.snapshot = { item:decoded,credential,expires:Date.now()+5*60*1000 };
    return decoded;
  }
}
