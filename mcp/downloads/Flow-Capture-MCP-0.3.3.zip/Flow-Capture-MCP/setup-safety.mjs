import { spawnSync } from 'node:child_process';

// Claude persists its in-memory settings on quit. Writing its JSON while it is
// open can appear successful and then disappear on the next restart.
export function requireClaudeClosed(run = spawnSync) {
  const result = run('/usr/bin/pgrep', ['-x', 'Claude'], { stdio: 'ignore' });
  if (result.status === 0) throw new Error('Quit Claude Desktop with Command-Q after its tasks finish, then run setup again. No settings have been changed.');
  if (result.error || result.status !== 1) throw new Error('Could not check whether Claude Desktop is closed. Setup stopped to protect its settings.');
}
