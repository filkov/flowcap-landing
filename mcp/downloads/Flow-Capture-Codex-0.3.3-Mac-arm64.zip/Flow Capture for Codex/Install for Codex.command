#!/bin/bash
set -eu
cd -- "$(dirname -- "$0")"
printf '\nFlow Capture for Codex\n\n'
flowcap_node="$PWD/runtime/bin/node"
if [ "$(uname -m)" != "arm64" ]; then
  printf 'This preview installer is for Apple Silicon Macs (M1 or newer). The source package is available for other Macs.\n'
  read -r -p 'Press Return to close. ' _
  exit 1
fi
if [ ! -x "$flowcap_node" ]; then
  printf 'The installer is incomplete. Download and unzip the complete Flow Capture for Codex package again.\n'
  read -r -p 'Press Return to close. ' _
  exit 1
fi
if "$flowcap_node" install.mjs --client=codex --cloud https://omhelpzpkowcncvqfnuw.supabase.co; then
  printf '\nOpen a new Codex chat and say: Connect my Flow Capture account.\nIf the tools are not visible yet, restart Codex after your other tasks finish.\n'
else
  printf '\nSetup did not finish. The error above explains the next step.\n'
  read -r -p 'Press Return to close. ' _
  exit 1
fi
read -r -p 'Press Return to close. ' _
